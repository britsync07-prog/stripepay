-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: blackdesck
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` bigint unsigned DEFAULT NULL,
  `event` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` bigint unsigned DEFAULT NULL,
  `attribute_changes` json DEFAULT NULL,
  `properties` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject` (`subject_type`,`subject_id`),
  KEY `causer` (`causer_type`,`causer_id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,'lead','Lead added','App\\Models\\ConsultationRequest',3,NULL,'App\\Models\\User',1,'[]','{\"type\": \"created\", \"message\": \"Lead added manually\"}','2026-07-04 16:09:56','2026-07-04 16:09:56'),(2,'consultation','Priced custom request','App\\Models\\ConsultationRequest',3,NULL,'App\\Models\\User',1,'[]','{\"amount\": 500, \"currency\": \"USD\"}','2026-07-04 16:10:10','2026-07-04 16:10:10'),(3,'consultation','Emailed payment link to client','App\\Models\\ConsultationRequest',3,NULL,'App\\Models\\User',1,'[]','{\"email\": \"fadwa@test.com\"}','2026-07-04 16:10:12','2026-07-04 16:10:12'),(4,'payment','Consultation payment completed','App\\Models\\ConsultationRequest',3,NULL,'App\\Models\\User',1,'[]','{\"amount\": 500, \"gateway\": \"stripe\", \"currency\": \"USD\", \"reference\": \"cs_live_a15CBU3EflI2GdBr5HpKMjdJF5814V5IqdQwDTinRyXDE1n699pEmVuc69\", \"payment_id\": 1}','2026-07-04 16:13:08','2026-07-04 16:13:08'),(5,'lead','Lead won','App\\Models\\ConsultationRequest',3,NULL,'App\\Models\\User',1,'[]','{\"type\": \"stage\", \"message\": \"Lead won on payment\", \"to_label\": \"Won\"}','2026-07-04 16:13:09','2026-07-04 16:13:09'),(6,'project','Project created from consultation','App\\Models\\Project',1,NULL,'App\\Models\\User',1,'[]','{\"type\": \"created\", \"message\": \"Project created from CD-2026-000003\"}','2026-07-04 16:13:09','2026-07-04 16:13:09'),(7,'invoice','Invoice issued','App\\Models\\Invoice',1,NULL,'App\\Models\\User',1,'[]','{\"type\": \"issued\", \"total\": 500, \"message\": \"Invoice INV-2026-0001 issued\", \"currency\": \"USD\"}','2026-07-04 16:13:09','2026-07-04 16:13:09'),(8,'lead','Lead added','App\\Models\\ConsultationRequest',7,NULL,'App\\Models\\User',1,'[]','{\"type\": \"created\", \"message\": \"Lead added manually\"}','2026-07-05 13:42:21','2026-07-05 13:42:21'),(9,'consultation','Priced custom request','App\\Models\\ConsultationRequest',7,NULL,'App\\Models\\User',1,'[]','{\"amount\": 9000, \"currency\": \"USD\"}','2026-07-05 13:42:53','2026-07-05 13:42:53'),(10,'payment','Consultation payment completed','App\\Models\\ConsultationRequest',7,NULL,'App\\Models\\User',1,'[]','{\"amount\": 9000, \"gateway\": \"stripe\", \"currency\": \"USD\", \"reference\": \"cs_live_a1Wa6g5ErBvpBDM9YnIKYPzyQzuC1AAoQ9DDzVo6ExHKhelC8jQeQWCVnt\", \"payment_id\": 2}','2026-07-05 13:49:14','2026-07-05 13:49:14'),(11,'lead','Lead won','App\\Models\\ConsultationRequest',7,NULL,'App\\Models\\User',1,'[]','{\"type\": \"stage\", \"message\": \"Lead won on payment\", \"to_label\": \"Won\"}','2026-07-05 13:49:14','2026-07-05 13:49:14'),(12,'project','Project created from consultation','App\\Models\\Project',2,NULL,'App\\Models\\User',1,'[]','{\"type\": \"created\", \"message\": \"Project created from CD-2026-000007\"}','2026-07-05 13:49:14','2026-07-05 13:49:14'),(13,'invoice','Invoice issued','App\\Models\\Invoice',2,NULL,'App\\Models\\User',1,'[]','{\"type\": \"issued\", \"total\": 9000, \"message\": \"Invoice INV-2026-0002 issued\", \"currency\": \"USD\"}','2026-07-05 13:49:14','2026-07-05 13:49:14'),(14,'lead','Lead added','App\\Models\\ConsultationRequest',9,NULL,'App\\Models\\User',1,'[]','{\"type\": \"created\", \"message\": \"Lead added manually\"}','2026-07-05 18:30:14','2026-07-05 18:30:14'),(15,'consultation','Priced custom request','App\\Models\\ConsultationRequest',9,NULL,'App\\Models\\User',1,'[]','{\"amount\": 10000, \"currency\": \"USD\"}','2026-07-05 18:32:10','2026-07-05 18:32:10'),(16,'payment','Consultation payment completed','App\\Models\\ConsultationRequest',9,NULL,'App\\Models\\User',1,'[]','{\"amount\": 10000, \"gateway\": \"stripe\", \"currency\": \"USD\", \"reference\": \"cs_live_a1CqSYrjgCTckqcVpvakTzgcS3PeFNfAQBTDOIX0jYrBK7lF7vwUDlfLdd\", \"payment_id\": 3}','2026-07-05 18:45:19','2026-07-05 18:45:19'),(17,'lead','Lead won','App\\Models\\ConsultationRequest',9,NULL,'App\\Models\\User',1,'[]','{\"type\": \"stage\", \"message\": \"Lead won on payment\", \"to_label\": \"Won\"}','2026-07-05 18:45:19','2026-07-05 18:45:19'),(18,'project','Project created from consultation','App\\Models\\Project',3,NULL,'App\\Models\\User',1,'[]','{\"type\": \"created\", \"message\": \"Project created from CD-2026-000009\"}','2026-07-05 18:45:19','2026-07-05 18:45:19'),(19,'invoice','Invoice issued','App\\Models\\Invoice',3,NULL,'App\\Models\\User',1,'[]','{\"type\": \"issued\", \"total\": 10000, \"message\": \"Invoice INV-2026-0003 issued\", \"currency\": \"USD\"}','2026-07-05 18:45:19','2026-07-05 18:45:19'),(20,'lead','Lead added','App\\Models\\ConsultationRequest',10,NULL,'App\\Models\\User',1,'[]','{\"type\": \"created\", \"message\": \"Lead added manually\"}','2026-07-05 19:02:46','2026-07-05 19:02:46'),(21,'consultation','Priced custom request','App\\Models\\ConsultationRequest',10,NULL,'App\\Models\\User',1,'[]','{\"amount\": 10000, \"currency\": \"USD\"}','2026-07-05 19:03:29','2026-07-05 19:03:29'),(22,'lead','Lead added','App\\Models\\ConsultationRequest',11,NULL,'App\\Models\\User',1,'[]','{\"type\": \"created\", \"message\": \"Lead added manually\"}','2026-07-06 14:09:09','2026-07-06 14:09:09'),(23,'consultation','Priced custom request','App\\Models\\ConsultationRequest',11,NULL,'App\\Models\\User',1,'[]','{\"amount\": 10000, \"currency\": \"USD\"}','2026-07-06 14:09:33','2026-07-06 14:09:33'),(24,'payment','Created payment link','App\\Models\\ConsultationRequest',12,NULL,'App\\Models\\User',1,'[]','{\"type\": \"payment_link\", \"amount\": 10000, \"message\": \"Created payment link\", \"currency\": \"USD\"}','2026-07-06 15:17:02','2026-07-06 15:17:02'),(25,'payment','Created payment link','App\\Models\\ConsultationRequest',13,NULL,'App\\Models\\User',1,'[]','{\"type\": \"payment_link\", \"amount\": 10000, \"message\": \"Created payment link\", \"currency\": \"USD\"}','2026-07-06 15:28:21','2026-07-06 15:28:21'),(26,'payment','Created payment link','App\\Models\\ConsultationRequest',14,NULL,'App\\Models\\User',1,'[]','{\"type\": \"payment_link\", \"amount\": 10000, \"message\": \"Created payment link\", \"currency\": \"USD\"}','2026-07-06 15:30:33','2026-07-06 15:30:33'),(27,'payment','Consultation payment completed','App\\Models\\ConsultationRequest',13,NULL,NULL,NULL,'[]','{\"amount\": 10000, \"gateway\": \"stripe\", \"currency\": \"USD\", \"reference\": \"cs_live_a1psQ9DkeX7LdNUhNdw9vTCieixgnO593lfDkP19vijQP4Ne5qP56n5BBu\", \"payment_id\": 4}','2026-07-06 19:17:02','2026-07-06 19:17:02'),(28,'project','Project created from consultation','App\\Models\\Project',4,NULL,NULL,NULL,'[]','{\"type\": \"created\", \"message\": \"Project created from CD-2026-000013\"}','2026-07-06 19:17:03','2026-07-06 19:17:03'),(29,'invoice','Invoice issued','App\\Models\\Invoice',4,NULL,NULL,NULL,'[]','{\"type\": \"issued\", \"total\": 10000, \"message\": \"Invoice INV-2026-0004 issued\", \"currency\": \"USD\"}','2026-07-06 19:17:03','2026-07-06 19:17:03'),(30,'lead','Lead added','App\\Models\\ConsultationRequest',21,NULL,'App\\Models\\User',1,'[]','{\"type\": \"created\", \"message\": \"Lead added manually\"}','2026-07-07 16:04:49','2026-07-07 16:04:49'),(31,'project','Project created from consultation','App\\Models\\Project',5,NULL,'App\\Models\\User',1,'[]','{\"type\": \"created\", \"message\": \"Project created from CD-2026-000021\"}','2026-07-07 16:04:49','2026-07-07 16:04:49'),(32,'payment','Created payment link','App\\Models\\ConsultationRequest',22,NULL,'App\\Models\\User',1,'[]','{\"type\": \"payment_link\", \"amount\": 200000, \"message\": \"Created payment link\", \"currency\": \"USD\"}','2026-07-07 17:46:33','2026-07-07 17:46:33'),(33,'payment','Consultation payment completed','App\\Models\\ConsultationRequest',14,NULL,NULL,NULL,'[]','{\"amount\": 10000, \"gateway\": \"stripe\", \"currency\": \"USD\", \"reference\": \"cs_live_a1jwXRe513u3ZoKxdOG6E74TfL91CB1hrdakZC76LqogNJrhM5jJg8MJzS\", \"payment_id\": 5}','2026-07-07 17:46:38','2026-07-07 17:46:38'),(34,'project','Project created from consultation','App\\Models\\Project',6,NULL,NULL,NULL,'[]','{\"type\": \"created\", \"message\": \"Project created from CD-2026-000014\"}','2026-07-07 17:46:38','2026-07-07 17:46:38'),(35,'invoice','Invoice issued','App\\Models\\Invoice',5,NULL,NULL,NULL,'[]','{\"type\": \"issued\", \"total\": 10000, \"message\": \"Invoice INV-2026-0005 issued\", \"currency\": \"USD\"}','2026-07-07 17:46:38','2026-07-07 17:46:38'),(36,'payment','Created payment link','App\\Models\\ConsultationRequest',23,NULL,'App\\Models\\User',1,'[]','{\"type\": \"payment_link\", \"amount\": 500000, \"message\": \"Created payment link\", \"currency\": \"USD\"}','2026-07-08 13:03:31','2026-07-08 13:03:31'),(37,'payment','Created payment link','App\\Models\\ConsultationRequest',24,NULL,'App\\Models\\User',1,'[]','{\"type\": \"payment_link\", \"amount\": 50000, \"message\": \"Created payment link\", \"currency\": \"USD\"}','2026-07-08 13:24:30','2026-07-08 13:24:30'),(38,'payment','Created payment link','App\\Models\\ConsultationRequest',25,NULL,'App\\Models\\User',1,'[]','{\"type\": \"payment_link\", \"amount\": 30000, \"message\": \"Created payment link\", \"currency\": \"USD\"}','2026-07-08 13:27:52','2026-07-08 13:27:52'),(39,'payment','Created payment link','App\\Models\\ConsultationRequest',26,NULL,'App\\Models\\User',1,'[]','{\"type\": \"payment_link\", \"amount\": 100000, \"message\": \"Created payment link\", \"currency\": \"USD\"}','2026-07-08 13:51:09','2026-07-08 13:51:09'),(40,'consultation','Client requested a custom plan','App\\Models\\ConsultationRequest',27,NULL,NULL,NULL,'[]','{\"email\": \"mdsaimon552723@gmail.com\"}','2026-07-08 16:36:42','2026-07-08 16:36:42'),(41,'project','Project created from consultation','App\\Models\\Project',7,NULL,NULL,NULL,'[]','{\"type\": \"created\", \"message\": \"Project created from CD-2026-000027\"}','2026-07-08 16:36:42','2026-07-08 16:36:42'),(42,'consultation','Client requested a custom plan','App\\Models\\ConsultationRequest',28,NULL,NULL,NULL,'[]','{\"email\": \"dsnoda@gmail.com\"}','2026-07-09 10:47:16','2026-07-09 10:47:16'),(43,'project','Project created from consultation','App\\Models\\Project',8,NULL,NULL,NULL,'[]','{\"type\": \"created\", \"message\": \"Project created from CD-2026-000028\"}','2026-07-09 10:47:16','2026-07-09 10:47:16');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('blackdesck-cache-f4c44c6dc02213edfbf53536971ab328','i:1;',1783244739),('blackdesck-cache-f4c44c6dc02213edfbf53536971ab328:timer','i:1783244739;',1783244739);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consultation_requests`
--

DROP TABLE IF EXISTS `consultation_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consultation_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quote_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quote_issued_at` date DEFAULT NULL,
  `plan_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `contact_id` bigint unsigned DEFAULT NULL,
  `expert_id` bigint unsigned DEFAULT NULL,
  `consultation_type_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `scope_items` json DEFAULT NULL,
  `line_items` json DEFAULT NULL,
  `delivery_timeline` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `urgency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `budget_min` bigint unsigned DEFAULT NULL,
  `budget_max` bigint unsigned DEFAULT NULL,
  `budget_currency` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` bigint unsigned NOT NULL DEFAULT '0',
  `currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `checkout_gateway` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `checkout_reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `work_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `lead_stage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `next_follow_up_at` timestamp NULL DEFAULT NULL,
  `lost_reason` text COLLATE utf8mb4_unicode_ci,
  `lead_score` tinyint unsigned DEFAULT NULL,
  `lead_score_summary` text COLLATE utf8mb4_unicode_ci,
  `lead_score_flags` json DEFAULT NULL,
  `lead_scored_at` timestamp NULL DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `assigned_at` timestamp NULL DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `consultation_requests_uuid_unique` (`uuid`),
  UNIQUE KEY `consultation_requests_reference_unique` (`reference`),
  UNIQUE KEY `consultation_requests_quote_number_unique` (`quote_number`),
  KEY `consultation_requests_plan_id_foreign` (`plan_id`),
  KEY `consultation_requests_status_index` (`status`),
  KEY `consultation_requests_email_index` (`email`),
  KEY `consultation_requests_user_id_foreign` (`user_id`),
  KEY `consultation_requests_expert_id_foreign` (`expert_id`),
  KEY `consultation_requests_consultation_type_id_foreign` (`consultation_type_id`),
  KEY `consultation_requests_lead_stage_index` (`lead_stage`),
  KEY `consultation_requests_contact_id_foreign` (`contact_id`),
  CONSTRAINT `consultation_requests_consultation_type_id_foreign` FOREIGN KEY (`consultation_type_id`) REFERENCES `consultation_types` (`id`) ON DELETE SET NULL,
  CONSTRAINT `consultation_requests_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `consultation_requests_expert_id_foreign` FOREIGN KEY (`expert_id`) REFERENCES `experts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `consultation_requests_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL,
  CONSTRAINT `consultation_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultation_requests`
--

LOCK TABLES `consultation_requests` WRITE;
/*!40000 ALTER TABLE `consultation_requests` DISABLE KEYS */;
INSERT INTO `consultation_requests` VALUES (1,'b1347c91-6bc0-4062-938d-9e4ab884b027','CD-2026-000001',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,500000,'USD',NULL,NULL,'pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-04 13:59:35','2026-07-04 13:59:35'),(2,'10b5b6bb-8056-4e4f-8a77-6b9ca48b50b9','CD-2026-000002',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,500000,'USD','stripe','cs_live_a1jKwIfZzZyS43eQwVeK3SujIiTlVy24toJrQ2zGmAaIMng4qyfncrwadv','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-04 15:50:07','2026-07-04 16:08:01'),(3,'14963333-404e-45ac-8e05-dc79ac6dd264','CD-2026-000003',NULL,NULL,NULL,'New Test Plan',2,1,NULL,NULL,'Fadwa Fakir Test','fadwa@test.com','+971564614167','XYZ','AF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,500,'USD','stripe','cs_live_a15CBU3EflI2GdBr5HpKMjdJF5814V5IqdQwDTinRyXDE1n699pEmVuc69','paid','new','won','manual',NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-04 16:13:08','2026-07-18 16:10:10',NULL,NULL,NULL,'2026-07-04 16:09:56','2026-07-04 16:13:09'),(4,'16276db6-8ba0-4af4-84e3-a9b8ba95cf75','CD-2026-000004',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,500000,'USD','stripe','cs_live_a1wuUdKkpUOMe31J27YQ3U5zcVxpRnxA0wlf8LFicfoazP96QfT7xtqg7j','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-04 16:57:07','2026-07-04 16:57:08'),(5,'d4fbc3e1-8457-46b1-9ba4-6f57806cdfb2','CD-2026-000005',NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1200000,'USD','stripe','cs_live_a196fvBKTTLQGaDleTMExpvCazChRycHIYkVwKZGVw8YmX8u9a0403jKQC','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-04 16:58:32','2026-07-04 16:58:33'),(6,'480a8df7-c945-481e-b0c3-f55085fe4538','CD-2026-000006',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,500000,'USD','stripe','cs_live_a1qBo0mBdHnSG5mJUl28OAsf3RN6cvpX4AIejSymOSki1v624bNIkNwqa3','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-04 19:27:15','2026-07-04 19:27:24'),(7,'a737f8e1-ac72-463f-9693-6e0368b38c7b','CD-2026-000007',NULL,NULL,NULL,'Marking Fees',3,2,NULL,NULL,'Speed of FZC','ghamedbdear12345678@gmail.com','+971566195221','Speed of FZC','AE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,9000,'USD','stripe','cs_live_a1Wa6g5ErBvpBDM9YnIKYPzyQzuC1AAoQ9DDzVo6ExHKhelC8jQeQWCVnt','paid','new','won','manual',NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-05 13:49:14','2026-07-19 13:42:53',NULL,NULL,NULL,'2026-07-05 13:42:21','2026-07-05 13:49:14'),(8,'4d2427dc-cf89-44e8-beb2-2e334e174acc','CD-2026-000008',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,500000,'USD','stripe','cs_live_a1TZjLDHR3MjLSqCDSD4wFS0yi0wOggro8drLKVk2J5nL3OwxhyT0XKsLK','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-05 14:24:17','2026-07-05 14:24:19'),(9,'aa4bea4b-a3f2-429b-9699-36e74434f8b8','CD-2026-000009',NULL,NULL,NULL,'Speed for FZC — Web Platform Consultation',3,2,NULL,NULL,'Ghamed bdear','ghamedbdear12345678@gmail.com','+971566195221','Speed of FZC','AE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10000,'USD','stripe','cs_live_a1CqSYrjgCTckqcVpvakTzgcS3PeFNfAQBTDOIX0jYrBK7lF7vwUDlfLdd','paid','new','won','manual',NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-05 18:45:19','2026-07-19 18:32:10',NULL,NULL,NULL,'2026-07-05 18:30:14','2026-07-05 18:45:19'),(10,'ae05c024-5430-4542-adde-cc227803fd28','CD-2026-000010',NULL,NULL,NULL,'Speed for ZFC - Consultation',NULL,2,NULL,NULL,'Ghamed Bdear','ghamedbdear12345678@gmail.com',NULL,'Speed of FZC','AE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10000,'USD','stripe','cs_live_a1DIh1MFXAuk6v77l9p415iXMuNCXOrAo1awXfAcxYSeXgMZmQdpnAPdn5','pending','new','new','manual','2026-07-22 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-19 19:03:29',NULL,NULL,NULL,'2026-07-05 19:02:46','2026-07-07 00:04:21'),(11,'2b4c0983-a513-44fd-9147-0ebb301da804','CD-2026-000011',NULL,NULL,NULL,'Consulation Service',NULL,2,NULL,NULL,'Ghamed Bdear','ghamedbdear12345678@gmail.com',NULL,'Speed of FZC','GE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10000,'USD','stripe','cs_live_a1kvVdPRFa2IVRQnrrN1WPpFg9qzNMCfskslsd7fPBqBbATq0KvK4K0l6v','pending','new','new','manual','2026-07-10 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-20 14:09:33',NULL,NULL,NULL,'2026-07-06 14:09:09','2026-07-06 14:13:57'),(12,'fe5f9e1f-a4bd-4255-ba67-76bda0bb47df','CD-2026-000012',NULL,NULL,NULL,'Consultation',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10000,'USD','stripe','cs_live_a1BsqESwwND9RKRnLEIuzL03M6DRGuy1MpjtvxDK7Kbf9bRhELFWdCRvTv','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-06 15:17:01','2026-07-09 17:29:34'),(13,'e43de2ea-3b6a-4caa-80f7-4eb895587ddb','CD-2026-000013',NULL,NULL,NULL,'Consultation',4,3,NULL,NULL,'MARRAKECH CO','ay0820300@gmail.com','+96590965827',NULL,'KW',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10000,'USD','stripe','cs_live_a1psQ9DkeX7LdNUhNdw9vTCieixgnO593lfDkP19vijQP4Ne5qP56n5BBu','paid','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-06 19:17:02',NULL,NULL,NULL,NULL,'2026-07-06 15:28:21','2026-07-06 19:17:02'),(14,'17c1c96c-a86c-41cb-af46-aea9f12c4a0e','CD-2026-000014',NULL,NULL,NULL,'Consultation',7,4,NULL,NULL,'Ziya erdal','haıbegencel@gmail.com','+905349875634',NULL,'TR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10000,'USD','stripe','cs_live_a1jwXRe513u3ZoKxdOG6E74TfL91CB1hrdakZC76LqogNJrhM5jJg8MJzS','paid','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-07 17:46:38',NULL,NULL,NULL,NULL,'2026-07-06 15:30:33','2026-07-07 17:46:38'),(15,'bf7c2e67-9acd-4fee-b265-1d0eada9d4b5','CD-2026-000015',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,500000,'USD','stripe','cs_live_a12DdDypIPoRMwz8UlRyyIZyZPJOyJlSsRaHwNmpceul3H9L7XoOMKcwDn','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-06 22:13:43','2026-07-06 22:13:44'),(16,'d9894848-31ec-4977-a2ad-5e8e91a899cd','CD-2026-000016',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,500000,'USD','stripe','cs_live_a1v8iwRYhcExJ68ZoHvx9Sbgb9iOaLCq1vKicnpozj0GdbyTbsEbOhzTwC','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-06 22:17:25','2026-07-06 22:17:26'),(17,'5b525fb9-6a4f-40a5-a184-91ab4b084501','CD-2026-000017',NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1200000,'USD','stripe','cs_live_a1r9Qy9TV0EMdyqtxhK8OSLei6Mhu7ql3lM8vnmCFD7DsZHA5X3CLqffxk','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-06 22:19:36','2026-07-06 22:19:38'),(18,'ec8e4aaf-4f98-4271-b49f-680190e02b71','CD-2026-000018',NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1200000,'USD','stripe','cs_live_a15DuwbIMyomJ7spRe68rd4vGaDUB74iMMFidM7LGlf1Nvd8P5xuatgrjF','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-06 22:23:39','2026-07-06 22:23:40'),(19,'cba1094c-dc6f-46b4-a5b3-caf037b33e3c','CD-2026-000019',NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1200000,'USD','stripe','cs_live_a1985wzYp7rwSOk2P2dpHf1KzLGlWloj2kUzsqvnoGFSmj7ZzHblLQii0Y','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-06 22:27:45','2026-07-06 22:27:46'),(20,'262b1115-8d1d-4cb4-bada-447158bf5398','CD-2026-000020',NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1200000,'USD','stripe','cs_live_a1PgYJfiPgQOMncySPeBnWKBW4Od9kaKXJ1H92G4KxHqrJ9sXjUOrosVrU','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-06 22:50:53','2026-07-06 22:50:54'),(21,'601ce714-8155-429b-81ee-79adb048bdfa','CD-2026-000021',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'USD',NULL,NULL,'pending','new','new','manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-07 16:04:49','2026-07-07 16:04:49'),(22,'336f1b6c-839b-49b5-8a15-3fde9ca21ebd','CD-2026-000022',NULL,NULL,NULL,'Strategic Business Assessment',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,200000,'USD','stripe','cs_live_a1R400x5Ddv9skJ3G5zgM5t7sAYZxopBPOJrRsbP4Pv7N6x1JwW0YhtB9Q','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-21 17:46:33',NULL,NULL,NULL,'2026-07-07 17:46:33','2026-07-08 18:03:18'),(23,'bda6bbf5-548d-4efd-9294-05701e2b23f7','CD-2026-000023',NULL,NULL,NULL,'International Business Expansion',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,500000,'USD','stripe','cs_live_a1nWWdpujvi1CTFjXbsnjwNzf71NXO7xb9w3CBhikVfC4nHN2cbWgPAsSq','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-22 13:03:31',NULL,NULL,NULL,'2026-07-08 13:03:31','2026-07-09 16:15:24'),(24,'6c02dff2-24b0-4ea7-9cd6-ee465f528d6a','CD-2026-000024',NULL,NULL,NULL,'phone',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50000,'USD','stripe','cs_live_a1op3GNQG23rc98YQZhQMlgLyUHIyh42P71ufMualtsvIz4zF5KbCbSn4d','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-22 13:24:30',NULL,NULL,NULL,'2026-07-08 13:24:30','2026-07-09 17:15:55'),(25,'5ee71961-bb82-4a82-8ccf-465cf7c0e229','CD-2026-000025',NULL,NULL,NULL,'remote consultation',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,30000,'USD',NULL,NULL,'pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-16 13:27:52',NULL,NULL,NULL,'2026-07-08 13:27:52','2026-07-08 13:27:52'),(26,'c3ed0c1c-48fe-42a8-9219-3651d67010c7','CD-2026-000026',NULL,NULL,NULL,'business assessment remote',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100000,'USD','stripe','cs_live_a1uDQYkxO8d1A1qPmymF8eOFAUgS2ZvJVHjlsHJFfDRtZjJHULA1pWo9FA','pending','new',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-22 13:51:09',NULL,NULL,NULL,'2026-07-08 13:51:09','2026-07-08 18:03:44'),(27,'36e4ed7f-310a-4013-84e0-1876452eee8e','CD-2026-000027',NULL,NULL,NULL,'Custom plan request',NULL,5,NULL,NULL,'md saimon','mdsaimon552723@gmail.com',NULL,'testing','BD','Budget: 50\n\nits aa test',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'USD',NULL,NULL,'pending','new','new','form',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-08 16:36:42','2026-07-08 16:36:42'),(28,'784bbe7d-0480-4c5e-8390-45637ac0b342','CD-2026-000028',NULL,NULL,NULL,'Custom plan request',NULL,6,NULL,NULL,'dfsafds','dsnoda@gmail.com',NULL,'fsdfsfs','AL','Budget: 454\n\nfgs fdfds dsfs sdds',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'USD',NULL,NULL,'pending','new','new','form',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-09 10:47:16','2026-07-09 10:47:16');
/*!40000 ALTER TABLE `consultation_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consultation_types`
--

DROP TABLE IF EXISTS `consultation_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consultation_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `consultation_types_slug_unique` (`slug`),
  KEY `consultation_types_is_active_sort_order_index` (`is_active`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultation_types`
--

LOCK TABLES `consultation_types` WRITE;
/*!40000 ALTER TABLE `consultation_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `consultation_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `contacts_uuid_unique` (`uuid`),
  UNIQUE KEY `contacts_email_unique` (`email`),
  KEY `contacts_user_id_foreign` (`user_id`),
  CONSTRAINT `contacts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES (1,'d8d44a4f-52b2-4376-b31d-e37d577f929a','Fadwa Fakir Test','fadwa@test.com','XYZ','AF','+971564614167',2,'2026-07-06 15:11:40','2026-07-06 15:11:40'),(2,'c8f125d1-a2b6-458b-92fc-f9c8e2f9f551','Ghamed Bdear','ghamedbdear12345678@gmail.com','Speed of FZC','GE',NULL,3,'2026-07-06 15:11:40','2026-07-06 15:11:40'),(3,'1da4675e-d5bf-4fbf-b2a1-12a822205df7','MARRAKECH CO','ay0820300@gmail.com',NULL,'KW','+96590965827',4,'2026-07-06 19:17:02','2026-07-06 19:17:02'),(4,'fc48584f-74e7-4f7a-8d71-4f845a344ae6','Ziya erdal','haıbegencel@gmail.com',NULL,'TR','+905349875634',7,'2026-07-07 17:46:38','2026-07-07 17:46:38'),(5,'7bfb1e4e-c63a-4bc8-8c56-7e5d51583493','md saimon','mdsaimon552723@gmail.com','testing','BD',NULL,NULL,'2026-07-08 16:36:42','2026-07-08 16:36:42'),(6,'189fedc5-2ae4-45c8-97ff-1ce4f79815a4','dfsafds','dsnoda@gmail.com','fsdfsfs','AL',NULL,NULL,'2026-07-09 10:47:16','2026-07-09 10:47:16');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dial_code` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emoji` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `countries_code_unique` (`code`),
  KEY `countries_name_index` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=253 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'AF','Afghanistan','+93','🇦🇫'),(2,'AX','Aland','+358','🇦🇽'),(3,'AL','Albania','+355','🇦🇱'),(4,'DZ','Algeria','+213','🇩🇿'),(5,'AS','American Samoa','+1684','🇦🇸'),(6,'AD','Andorra','+376','🇦🇩'),(7,'AO','Angola','+244','🇦🇴'),(8,'AI','Anguilla','+1264','🇦🇮'),(9,'AQ','Antarctica','+672','🇦🇶'),(10,'AG','Antigua and Barbuda','+1268','🇦🇬'),(11,'AR','Argentina','+54','🇦🇷'),(12,'AM','Armenia','+374','🇦🇲'),(13,'AW','Aruba','+297','🇦🇼'),(14,'AC','Ascension Island','+247','🇦🇨'),(15,'AU','Australia','+61','🇦🇺'),(16,'AT','Austria','+43','🇦🇹'),(17,'AZ','Azerbaijan','+994','🇦🇿'),(18,'BS','Bahamas','+1242','🇧🇸'),(19,'BH','Bahrain','+973','🇧🇭'),(20,'BD','Bangladesh','+880','🇧🇩'),(21,'BB','Barbados','+1246','🇧🇧'),(22,'BY','Belarus','+375','🇧🇾'),(23,'BE','Belgium','+32','🇧🇪'),(24,'BZ','Belize','+501','🇧🇿'),(25,'BJ','Benin','+229','🇧🇯'),(26,'BM','Bermuda','+1441','🇧🇲'),(27,'BT','Bhutan','+975','🇧🇹'),(28,'BO','Bolivia','+591','🇧🇴'),(29,'BQ','Bonaire','+5997','🇧🇶'),(30,'BA','Bosnia and Herzegovina','+387','🇧🇦'),(31,'BW','Botswana','+267','🇧🇼'),(32,'BV','Bouvet Island','+47','🇧🇻'),(33,'BR','Brazil','+55','🇧🇷'),(34,'IO','British Indian Ocean Territory','+246','🇮🇴'),(35,'VG','British Virgin Islands','+1284','🇻🇬'),(36,'BN','Brunei','+673','🇧🇳'),(37,'BG','Bulgaria','+359','🇧🇬'),(38,'BF','Burkina Faso','+226','🇧🇫'),(39,'BI','Burundi','+257','🇧🇮'),(40,'KH','Cambodia','+855','🇰🇭'),(41,'CM','Cameroon','+237','🇨🇲'),(42,'CA','Canada','+1','🇨🇦'),(43,'CV','Cape Verde','+238','🇨🇻'),(44,'KY','Cayman Islands','+1345','🇰🇾'),(45,'CF','Central African Republic','+236','🇨🇫'),(46,'TD','Chad','+235','🇹🇩'),(47,'CL','Chile','+56','🇨🇱'),(48,'CN','China','+86','🇨🇳'),(49,'CX','Christmas Island','+61','🇨🇽'),(50,'CC','Cocos (Keeling) Islands','+61','🇨🇨'),(51,'CO','Colombia','+57','🇨🇴'),(52,'KM','Comoros','+269','🇰🇲'),(53,'CK','Cook Islands','+682','🇨🇰'),(54,'CR','Costa Rica','+506','🇨🇷'),(55,'HR','Croatia','+385','🇭🇷'),(56,'CU','Cuba','+53','🇨🇺'),(57,'CW','Curacao','+5999','🇨🇼'),(58,'CY','Cyprus','+357','🇨🇾'),(59,'CZ','Czech Republic','+420','🇨🇿'),(60,'CD','Democratic Republic of the Congo','+243','🇨🇩'),(61,'DK','Denmark','+45','🇩🇰'),(62,'DJ','Djibouti','+253','🇩🇯'),(63,'DM','Dominica','+1767','🇩🇲'),(64,'DO','Dominican Republic','+1809','🇩🇴'),(65,'TL','East Timor','+670','🇹🇱'),(66,'EC','Ecuador','+593','🇪🇨'),(67,'EG','Egypt','+20','🇪🇬'),(68,'SV','El Salvador','+503','🇸🇻'),(69,'GQ','Equatorial Guinea','+240','🇬🇶'),(70,'ER','Eritrea','+291','🇪🇷'),(71,'EE','Estonia','+372','🇪🇪'),(72,'SZ','Eswatini','+268','🇸🇿'),(73,'ET','Ethiopia','+251','🇪🇹'),(74,'FK','Falkland Islands','+500','🇫🇰'),(75,'FO','Faroe Islands','+298','🇫🇴'),(76,'FJ','Fiji','+679','🇫🇯'),(77,'FI','Finland','+358','🇫🇮'),(78,'FR','France','+33','🇫🇷'),(79,'GF','French Guiana','+594','🇬🇫'),(80,'PF','French Polynesia','+689','🇵🇫'),(81,'TF','French Southern Territories','+262','🇹🇫'),(82,'GA','Gabon','+241','🇬🇦'),(83,'GM','Gambia','+220','🇬🇲'),(84,'GE','Georgia','+995','🇬🇪'),(85,'DE','Germany','+49','🇩🇪'),(86,'GH','Ghana','+233','🇬🇭'),(87,'GI','Gibraltar','+350','🇬🇮'),(88,'GR','Greece','+30','🇬🇷'),(89,'GL','Greenland','+299','🇬🇱'),(90,'GD','Grenada','+1473','🇬🇩'),(91,'GP','Guadeloupe','+590','🇬🇵'),(92,'GU','Guam','+1671','🇬🇺'),(93,'GT','Guatemala','+502','🇬🇹'),(94,'GG','Guernsey','+44','🇬🇬'),(95,'GN','Guinea','+224','🇬🇳'),(96,'GW','Guinea-Bissau','+245','🇬🇼'),(97,'GY','Guyana','+592','🇬🇾'),(98,'HT','Haiti','+509','🇭🇹'),(99,'HM','Heard Island and McDonald Islands','+61','🇭🇲'),(100,'HN','Honduras','+504','🇭🇳'),(101,'HK','Hong Kong','+852','🇭🇰'),(102,'HU','Hungary','+36','🇭🇺'),(103,'IS','Iceland','+354','🇮🇸'),(104,'IN','India','+91','🇮🇳'),(105,'ID','Indonesia','+62','🇮🇩'),(106,'IR','Iran','+98','🇮🇷'),(107,'IQ','Iraq','+964','🇮🇶'),(108,'IE','Ireland','+353','🇮🇪'),(109,'IM','Isle of Man','+44','🇮🇲'),(110,'IL','Israel','+972','🇮🇱'),(111,'IT','Italy','+39','🇮🇹'),(112,'CI','Ivory Coast','+225','🇨🇮'),(113,'JM','Jamaica','+1876','🇯🇲'),(114,'JP','Japan','+81','🇯🇵'),(115,'JE','Jersey','+44','🇯🇪'),(116,'JO','Jordan','+962','🇯🇴'),(117,'KZ','Kazakhstan','+7','🇰🇿'),(118,'KE','Kenya','+254','🇰🇪'),(119,'KI','Kiribati','+686','🇰🇮'),(120,'XK','Kosovo','+377','🇽🇰'),(121,'KW','Kuwait','+965','🇰🇼'),(122,'KG','Kyrgyzstan','+996','🇰🇬'),(123,'LA','Laos','+856','🇱🇦'),(124,'LV','Latvia','+371','🇱🇻'),(125,'LB','Lebanon','+961','🇱🇧'),(126,'LS','Lesotho','+266','🇱🇸'),(127,'LR','Liberia','+231','🇱🇷'),(128,'LY','Libya','+218','🇱🇾'),(129,'LI','Liechtenstein','+423','🇱🇮'),(130,'LT','Lithuania','+370','🇱🇹'),(131,'LU','Luxembourg','+352','🇱🇺'),(132,'MO','Macao','+853','🇲🇴'),(133,'MG','Madagascar','+261','🇲🇬'),(134,'MW','Malawi','+265','🇲🇼'),(135,'MY','Malaysia','+60','🇲🇾'),(136,'MV','Maldives','+960','🇲🇻'),(137,'ML','Mali','+223','🇲🇱'),(138,'MT','Malta','+356','🇲🇹'),(139,'MH','Marshall Islands','+692','🇲🇭'),(140,'MQ','Martinique','+596','🇲🇶'),(141,'MR','Mauritania','+222','🇲🇷'),(142,'MU','Mauritius','+230','🇲🇺'),(143,'YT','Mayotte','+262','🇾🇹'),(144,'MX','Mexico','+52','🇲🇽'),(145,'FM','Micronesia','+691','🇫🇲'),(146,'MD','Moldova','+373','🇲🇩'),(147,'MC','Monaco','+377','🇲🇨'),(148,'MN','Mongolia','+976','🇲🇳'),(149,'ME','Montenegro','+382','🇲🇪'),(150,'MS','Montserrat','+1664','🇲🇸'),(151,'MA','Morocco','+212','🇲🇦'),(152,'MZ','Mozambique','+258','🇲🇿'),(153,'MM','Myanmar (Burma)','+95','🇲🇲'),(154,'NA','Namibia','+264','🇳🇦'),(155,'NR','Nauru','+674','🇳🇷'),(156,'NP','Nepal','+977','🇳🇵'),(157,'NL','Netherlands','+31','🇳🇱'),(158,'NC','New Caledonia','+687','🇳🇨'),(159,'NZ','New Zealand','+64','🇳🇿'),(160,'NI','Nicaragua','+505','🇳🇮'),(161,'NE','Niger','+227','🇳🇪'),(162,'NG','Nigeria','+234','🇳🇬'),(163,'NU','Niue','+683','🇳🇺'),(164,'NF','Norfolk Island','+672','🇳🇫'),(165,'KP','North Korea','+850','🇰🇵'),(166,'MK','North Macedonia','+389','🇲🇰'),(167,'MP','Northern Mariana Islands','+1670','🇲🇵'),(168,'NO','Norway','+47','🇳🇴'),(169,'OM','Oman','+968','🇴🇲'),(170,'PK','Pakistan','+92','🇵🇰'),(171,'PW','Palau','+680','🇵🇼'),(172,'PS','Palestine','+970','🇵🇸'),(173,'PA','Panama','+507','🇵🇦'),(174,'PG','Papua New Guinea','+675','🇵🇬'),(175,'PY','Paraguay','+595','🇵🇾'),(176,'PE','Peru','+51','🇵🇪'),(177,'PH','Philippines','+63','🇵🇭'),(178,'PN','Pitcairn Islands','+64','🇵🇳'),(179,'PL','Poland','+48','🇵🇱'),(180,'PT','Portugal','+351','🇵🇹'),(181,'PR','Puerto Rico','+1787','🇵🇷'),(182,'QA','Qatar','+974','🇶🇦'),(183,'CG','Republic of the Congo','+242','🇨🇬'),(184,'RE','Reunion','+262','🇷🇪'),(185,'RO','Romania','+40','🇷🇴'),(186,'RU','Russia','+7','🇷🇺'),(187,'RW','Rwanda','+250','🇷🇼'),(188,'BL','Saint Barthelemy','+590','🇧🇱'),(189,'SH','Saint Helena','+290','🇸🇭'),(190,'KN','Saint Kitts and Nevis','+1869','🇰🇳'),(191,'LC','Saint Lucia','+1758','🇱🇨'),(192,'MF','Saint Martin','+590','🇲🇫'),(193,'PM','Saint Pierre and Miquelon','+508','🇵🇲'),(194,'VC','Saint Vincent and the Grenadines','+1784','🇻🇨'),(195,'WS','Samoa','+685','🇼🇸'),(196,'SM','San Marino','+378','🇸🇲'),(197,'ST','Sao Tome and Principe','+239','🇸🇹'),(198,'SA','Saudi Arabia','+966','🇸🇦'),(199,'SN','Senegal','+221','🇸🇳'),(200,'RS','Serbia','+381','🇷🇸'),(201,'SC','Seychelles','+248','🇸🇨'),(202,'SL','Sierra Leone','+232','🇸🇱'),(203,'SG','Singapore','+65','🇸🇬'),(204,'SX','Sint Maarten','+1721','🇸🇽'),(205,'SK','Slovakia','+421','🇸🇰'),(206,'SI','Slovenia','+386','🇸🇮'),(207,'SB','Solomon Islands','+677','🇸🇧'),(208,'SO','Somalia','+252','🇸🇴'),(209,'ZA','South Africa','+27','🇿🇦'),(210,'GS','South Georgia and the South Sandwich Islands','+500','🇬🇸'),(211,'KR','South Korea','+82','🇰🇷'),(212,'SS','South Sudan','+211','🇸🇸'),(213,'ES','Spain','+34','🇪🇸'),(214,'LK','Sri Lanka','+94','🇱🇰'),(215,'SD','Sudan','+249','🇸🇩'),(216,'SR','Suriname','+597','🇸🇷'),(217,'SJ','Svalbard and Jan Mayen','+4779','🇸🇯'),(218,'SE','Sweden','+46','🇸🇪'),(219,'CH','Switzerland','+41','🇨🇭'),(220,'SY','Syria','+963','🇸🇾'),(221,'TW','Taiwan','+886','🇹🇼'),(222,'TJ','Tajikistan','+992','🇹🇯'),(223,'TZ','Tanzania','+255','🇹🇿'),(224,'TH','Thailand','+66','🇹🇭'),(225,'TG','Togo','+228','🇹🇬'),(226,'TK','Tokelau','+690','🇹🇰'),(227,'TO','Tonga','+676','🇹🇴'),(228,'TT','Trinidad and Tobago','+1868','🇹🇹'),(229,'TA','Tristan da Cunha','+290','🇹🇦'),(230,'TN','Tunisia','+216','🇹🇳'),(231,'TR','Türkiye','+90','🇹🇷'),(232,'TM','Turkmenistan','+993','🇹🇲'),(233,'TC','Turks and Caicos Islands','+1649','🇹🇨'),(234,'TV','Tuvalu','+688','🇹🇻'),(235,'UM','U.S. Minor Outlying Islands','+1','🇺🇲'),(236,'VI','U.S. Virgin Islands','+1340','🇻🇮'),(237,'UG','Uganda','+256','🇺🇬'),(238,'UA','Ukraine','+380','🇺🇦'),(239,'AE','United Arab Emirates','+971','🇦🇪'),(240,'GB','United Kingdom','+44','🇬🇧'),(241,'US','United States','+1','🇺🇸'),(242,'UY','Uruguay','+598','🇺🇾'),(243,'UZ','Uzbekistan','+998','🇺🇿'),(244,'VU','Vanuatu','+678','🇻🇺'),(245,'VA','Vatican City','+379','🇻🇦'),(246,'VE','Venezuela','+58','🇻🇪'),(247,'VN','Vietnam','+84','🇻🇳'),(248,'WF','Wallis and Futuna','+681','🇼🇫'),(249,'EH','Western Sahara','+212','🇪🇭'),(250,'YE','Yemen','+967','🇾🇪'),(251,'ZM','Zambia','+260','🇿🇲'),(252,'ZW','Zimbabwe','+263','🇿🇼');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currencies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `symbol` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` smallint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `currencies_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currencies`
--

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES (1,'USD','US Dollar','$',0,'2026-07-04 13:41:08','2026-07-04 13:41:08'),(2,'EUR','Euro','€',1,'2026-07-04 13:41:08','2026-07-04 13:41:08'),(3,'GBP','British Pound','£',2,'2026-07-04 13:41:08','2026-07-04 13:41:08'),(4,'AED','UAE Dirham','د.إ',3,'2026-07-04 13:41:08','2026-07-04 13:41:08'),(5,'MAD','Moroccan Dirham','DH',4,'2026-07-04 13:41:08','2026-07-04 13:41:08'),(6,'SAR','Saudi Riyal','﷼',5,'2026-07-04 13:41:08','2026-07-04 13:41:08'),(7,'CAD','Canadian Dollar','C$',6,'2026-07-04 13:41:08','2026-07-04 13:41:08'),(8,'AUD','Australian Dollar','A$',7,'2026-07-04 13:41:08','2026-07-04 13:41:08'),(9,'INR','Indian Rupee','₹',8,'2026-07-04 13:41:08','2026-07-04 13:41:08'),(10,'JPY','Japanese Yen','¥',9,'2026-07-04 13:41:08','2026-07-04 13:41:08'),(11,'CHF','Swiss Franc','CHF',10,'2026-07-04 13:41:08','2026-07-04 13:41:08'),(12,'CNY','Chinese Yuan','¥',11,'2026-07-04 13:41:08','2026-07-04 13:41:08');
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experts`
--

DROP TABLE IF EXISTS `experts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `experts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specialization` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `preferred_payout_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'stripe',
  `stripe_account_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_payouts_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `payout_notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experts`
--

LOCK TABLES `experts` WRITE;
/*!40000 ALTER TABLE `experts` DISABLE KEYS */;
INSERT INTO `experts` VALUES (1,'test','test@test.com','Marketing','AE',1,'stripe','acct_1TppmUFwowKhjIrJ',0,NULL,'2026-07-05 13:08:09','2026-07-05 13:30:45'),(2,'Ghamed Bdear','ghamedbdear12345678@gmail.com','Business Expansion','AE',1,'stripe','acct_1TpqDTCOxS01NsHS',1,NULL,'2026-07-05 13:31:04','2026-07-05 13:40:21');
/*!40000 ALTER TABLE `experts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_items`
--

DROP TABLE IF EXISTS `invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint unsigned NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int unsigned NOT NULL DEFAULT '1',
  `unit_amount` bigint unsigned NOT NULL DEFAULT '0',
  `amount` bigint unsigned NOT NULL DEFAULT '0',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_items_invoice_id_foreign` (`invoice_id`),
  CONSTRAINT `invoice_items_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_items`
--

LOCK TABLES `invoice_items` WRITE;
/*!40000 ALTER TABLE `invoice_items` DISABLE KEYS */;
INSERT INTO `invoice_items` VALUES (1,1,'New Test Plan',1,500,500,1,'2026-07-04 16:13:09','2026-07-04 16:13:09'),(2,2,'Marking Fees',1,9000,9000,1,'2026-07-05 13:49:14','2026-07-05 13:49:14'),(3,3,'Speed for FZC — Web Platform Consultation',1,10000,10000,1,'2026-07-05 18:45:19','2026-07-05 18:45:19'),(4,4,'Consultation',1,10000,10000,1,'2026-07-06 19:17:03','2026-07-06 19:17:03'),(5,5,'Consultation',1,10000,10000,1,'2026-07-07 17:46:38','2026-07-07 17:46:38');
/*!40000 ALTER TABLE `invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `consultation_request_id` bigint unsigned DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'paid',
  `subtotal` bigint unsigned NOT NULL DEFAULT '0',
  `tax_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `tax_amount` bigint unsigned NOT NULL DEFAULT '0',
  `total` bigint unsigned NOT NULL DEFAULT '0',
  `currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `issued_at` date DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoices_uuid_unique` (`uuid`),
  UNIQUE KEY `invoices_reference_unique` (`reference`),
  UNIQUE KEY `invoices_consultation_request_id_unique` (`consultation_request_id`),
  KEY `invoices_user_id_foreign` (`user_id`),
  CONSTRAINT `invoices_consultation_request_id_foreign` FOREIGN KEY (`consultation_request_id`) REFERENCES `consultation_requests` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (1,'3f068c80-5271-44a8-a8c1-2d2beacdd896','INV-2026-0001',2,3,'paid',500,0.00,0,500,'USD',NULL,'2026-07-04','2026-07-04 16:13:08','2026-07-04 16:13:09','2026-07-04 16:13:09'),(2,'d30b9687-d0b4-4526-87b4-3233c2945fb2','INV-2026-0002',3,7,'paid',9000,0.00,0,9000,'USD',NULL,'2026-07-05','2026-07-05 13:49:14','2026-07-05 13:49:14','2026-07-05 13:49:14'),(3,'11b13abb-05cf-46fc-853f-6a0f2390dea2','INV-2026-0003',3,9,'paid',10000,0.00,0,10000,'USD',NULL,'2026-07-05','2026-07-05 18:45:19','2026-07-05 18:45:19','2026-07-05 18:45:19'),(4,'63432c45-3300-4ff7-ab92-bb5ee10f79ac','INV-2026-0004',4,13,'paid',10000,0.00,0,10000,'USD',NULL,'2026-07-06','2026-07-06 19:17:02','2026-07-06 19:17:03','2026-07-06 19:17:03'),(5,'11658cc6-5dfa-47b0-a3bb-07044dfcf617','INV-2026-0005',7,14,'paid',10000,0.00,0,10000,'USD',NULL,'2026-07-07','2026-07-07 17:46:38','2026-07-07 17:46:38','2026-07-07 17:46:38');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversions_disk` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint unsigned NOT NULL,
  `manipulations` json NOT NULL,
  `custom_properties` json NOT NULL,
  `generated_conversions` json NOT NULL,
  `responsive_images` json NOT NULL,
  `order_column` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_uuid_unique` (`uuid`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `media_order_column_index` (`order_column`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2022_12_14_083707_create_settings_table',1),(5,'2024_01_01_000000_create_passkeys_table',1),(6,'2025_08_14_170933_add_two_factor_columns_to_users_table',1),(7,'2026_06_03_150000_create_plans_table',1),(8,'2026_06_03_152227_create_activity_log_table',1),(9,'2026_06_03_160000_create_consultation_requests_table',1),(10,'2026_06_03_160001_create_payments_table',1),(11,'2026_06_04_061351_create_permission_tables',1),(12,'2026_06_04_062000_add_user_id_to_consultation_requests_table',1),(13,'2026_06_04_092929_create_notifications_table',1),(14,'2026_06_04_115704_create_media_table',1),(15,'2026_06_04_118000_create_experts_table',1),(16,'2026_06_04_120000_create_payouts_table',1),(17,'2026_06_04_130000_add_work_status_to_consultation_requests_table',1),(18,'2026_06_04_140000_add_unique_index_to_payments_stripe_session_id',1),(19,'2026_06_04_140100_add_idempotency_key_to_payouts',1),(20,'2026_06_15_000000_create_consultation_types_table',1),(21,'2026_06_16_000000_add_ticket_fields_to_consultation_requests_table',1),(22,'2026_06_16_010000_generalize_payments_for_multi_gateway',1),(23,'2026_06_22_000000_add_custom_fields_to_consultation_requests_table',1),(24,'2026_06_22_000100_create_countries_table',1),(25,'2026_06_27_000000_create_projects_table',1),(26,'2026_06_27_000100_create_milestones_table',1),(27,'2026_06_27_000200_add_unique_consultation_to_projects',1),(28,'2026_06_27_000300_drop_brief_columns_from_projects',1),(29,'2026_06_28_000000_create_invoices_table',1),(30,'2026_06_28_000100_create_invoice_items_table',1),(31,'2026_06_28_000200_add_unique_consultation_to_invoices',1),(32,'2026_06_29_000000_add_lead_pipeline_to_consultation_requests',1),(33,'2026_06_29_000100_add_fee_net_to_payments',1),(34,'2026_06_29_000200_add_status_paid_at_index_to_payments',1),(35,'2026_07_01_000000_create_platform_settings',1),(36,'2026_07_01_100000_create_currencies_table',1),(37,'2026_07_02_000000_add_lead_score_to_consultation_requests',1),(38,'2026_07_02_010000_add_health_to_projects',1),(39,'2026_07_06_000000_create_contacts_table',2),(40,'2026_07_07_000000_add_quotation_to_consultation_requests',3),(41,'2026_07_07_000000_add_signatory_to_platform_settings',3),(42,'2026_07_07_010000_seed_quotation_letterhead',3),(43,'2026_07_08_000000_create_quotation_templates_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `milestones`
--

DROP TABLE IF EXISTS `milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `milestones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `due_date` date DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `milestones_project_id_foreign` (`project_id`),
  CONSTRAINT `milestones_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `milestones`
--

LOCK TABLES `milestones` WRITE;
/*!40000 ALTER TABLE `milestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `milestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(2,'App\\Models\\User',2),(2,'App\\Models\\User',3),(2,'App\\Models\\User',4),(2,'App\\Models\\User',7);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('002e3fee-8b88-4a97-8061-082e15226abd','App\\Notifications\\NewConsultationPaidNotification','App\\Models\\User',1,'{\"type\":\"consultation_paid\",\"title\":\"New paid consultation\",\"message\":\"Ghamed bdear paid $100 for a consultation.\",\"consultation_uuid\":\"aa4bea4b-a3f2-429b-9699-36e74434f8b8\",\"reference\":\"AA4BEA4B\",\"plan\":null,\"amount\":\"$100\",\"client_name\":\"Ghamed bdear\",\"client_email\":\"ghamedbdear12345678@gmail.com\",\"url\":\"\\/admin\\/consultations\\/aa4bea4b-a3f2-429b-9699-36e74434f8b8\"}',NULL,'2026-07-05 18:45:20','2026-07-05 18:45:20'),('01d6a02b-1848-45db-8f88-8e1fece7f053','App\\Notifications\\NewConsultationPaidNotification','App\\Models\\User',1,'{\"type\":\"consultation_paid\",\"title\":\"New paid consultation\",\"message\":\"Ziya erdal paid $100 for a consultation.\",\"consultation_uuid\":\"17c1c96c-a86c-41cb-af46-aea9f12c4a0e\",\"reference\":\"17C1C96C\",\"plan\":null,\"amount\":\"$100\",\"client_name\":\"Ziya erdal\",\"client_email\":\"ha\\u0131begencel@gmail.com\",\"url\":\"\\/admin\\/consultations\\/17c1c96c-a86c-41cb-af46-aea9f12c4a0e\"}','2026-07-08 16:15:20','2026-07-07 17:46:40','2026-07-08 16:15:20'),('18fa8a2d-4cd7-4c35-8e4a-a0406c1b6f65','App\\Notifications\\CustomPlanRequestedNotification','App\\Models\\User',1,'{\"type\":\"custom_plan_requested\",\"title\":\"Custom plan requested\",\"message\":\"md saimon requested a tailored plan.\",\"consultation_uuid\":\"36e4ed7f-310a-4013-84e0-1876452eee8e\",\"client_name\":\"md saimon\",\"client_email\":\"mdsaimon552723@gmail.com\",\"url\":\"\\/admin\\/consultations\\/36e4ed7f-310a-4013-84e0-1876452eee8e\"}',NULL,'2026-07-08 16:36:43','2026-07-08 16:36:43'),('24cbf979-605a-4551-9dc7-b3406e8f769a','App\\Notifications\\DashboardAccessNotification','App\\Models\\User',4,'{\"type\":\"payment_received\",\"title\":\"Payment received\",\"message\":\"Thank you for your payment \\u2014 your consultation is being prepared.\",\"url\":\"\\/portal\\/dashboard\"}',NULL,'2026-07-06 19:17:03','2026-07-06 19:17:03'),('35b53a27-26b6-4ae7-9edf-2fea4ac706f5','App\\Notifications\\NewConsultationPaidNotification','App\\Models\\User',1,'{\"type\":\"consultation_paid\",\"title\":\"New paid consultation\",\"message\":\"Speed of FZC paid $90 for a consultation.\",\"consultation_uuid\":\"a737f8e1-ac72-463f-9693-6e0368b38c7b\",\"reference\":\"A737F8E1\",\"plan\":null,\"amount\":\"$90\",\"client_name\":\"Speed of FZC\",\"client_email\":\"ghamedbdear12345678@gmail.com\",\"url\":\"\\/admin\\/consultations\\/a737f8e1-ac72-463f-9693-6e0368b38c7b\"}',NULL,'2026-07-05 13:49:14','2026-07-05 13:49:14'),('6bf11100-fa28-488a-a5e9-ef5b2aeac6aa','App\\Notifications\\DashboardAccessNotification','App\\Models\\User',3,'{\"type\":\"payment_received\",\"title\":\"Payment received\",\"message\":\"Thank you for your payment \\u2014 your consultation is being prepared.\",\"url\":\"\\/portal\\/dashboard\"}',NULL,'2026-07-05 18:45:19','2026-07-05 18:45:19'),('6f82390a-1f0d-462e-980e-197e6a59c8b7','App\\Notifications\\DashboardAccessNotification','App\\Models\\User',7,'{\"type\":\"payment_received\",\"title\":\"Payment received\",\"message\":\"Thank you for your payment \\u2014 your consultation is being prepared.\",\"url\":\"\\/portal\\/dashboard\"}',NULL,'2026-07-07 17:46:38','2026-07-07 17:46:38'),('81acb89b-f860-4b89-9e59-d2bc18139715','App\\Notifications\\NewConsultationPaidNotification','App\\Models\\User',1,'{\"type\":\"consultation_paid\",\"title\":\"New paid consultation\",\"message\":\"Fadwa Fakir Test paid $5 for a consultation.\",\"consultation_uuid\":\"14963333-404e-45ac-8e05-dc79ac6dd264\",\"reference\":\"14963333\",\"plan\":null,\"amount\":\"$5\",\"client_name\":\"Fadwa Fakir Test\",\"client_email\":\"fadwa@test.com\",\"url\":\"\\/admin\\/consultations\\/14963333-404e-45ac-8e05-dc79ac6dd264\"}','2026-07-08 16:15:18','2026-07-05 14:36:11','2026-07-08 16:15:18'),('a5e94d7b-e605-4371-84ef-8ce865ff1a54','App\\Notifications\\DashboardAccessNotification','App\\Models\\User',3,'{\"type\":\"payment_received\",\"title\":\"Payment received\",\"message\":\"Thank you for your payment \\u2014 your consultation is being prepared.\",\"url\":\"\\/portal\\/dashboard\"}',NULL,'2026-07-05 13:49:14','2026-07-05 13:49:14'),('df000308-37ac-44ac-a95a-b2e6ae169c9a','App\\Notifications\\NewConsultationPaidNotification','App\\Models\\User',1,'{\"type\":\"consultation_paid\",\"title\":\"New paid consultation\",\"message\":\"MARRAKECH CO paid $100 for a consultation.\",\"consultation_uuid\":\"e43de2ea-3b6a-4caa-80f7-4eb895587ddb\",\"reference\":\"E43DE2EA\",\"plan\":null,\"amount\":\"$100\",\"client_name\":\"MARRAKECH CO\",\"client_email\":\"ay0820300@gmail.com\",\"url\":\"\\/admin\\/consultations\\/e43de2ea-3b6a-4caa-80f7-4eb895587ddb\"}',NULL,'2026-07-06 19:17:03','2026-07-06 19:17:03'),('e5db5691-af77-46b8-b625-e7a2adde2d82','App\\Notifications\\DashboardAccessNotification','App\\Models\\User',2,'{\"type\":\"payment_received\",\"title\":\"Payment received\",\"message\":\"Thank you for your payment \\u2014 your consultation is being prepared.\",\"url\":\"\\/portal\\/dashboard\"}',NULL,'2026-07-04 16:13:09','2026-07-04 16:13:09'),('f7100a35-3f51-4bcc-bc49-3fb280e8891c','App\\Notifications\\CustomPlanRequestedNotification','App\\Models\\User',1,'{\"type\":\"custom_plan_requested\",\"title\":\"Custom plan requested\",\"message\":\"dfsafds requested a tailored plan.\",\"consultation_uuid\":\"784bbe7d-0480-4c5e-8390-45637ac0b342\",\"client_name\":\"dfsafds\",\"client_email\":\"dsnoda@gmail.com\",\"url\":\"\\/admin\\/consultations\\/784bbe7d-0480-4c5e-8390-45637ac0b342\"}',NULL,'2026-07-09 10:47:19','2026-07-09 10:47:19');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passkeys`
--

DROP TABLE IF EXISTS `passkeys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `passkeys` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `credential_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `credential` json NOT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `passkeys_credential_id_unique` (`credential_id`),
  KEY `passkeys_user_id_index` (`user_id`),
  CONSTRAINT `passkeys_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passkeys`
--

LOCK TABLES `passkeys` WRITE;
/*!40000 ALTER TABLE `passkeys` DISABLE KEYS */;
/*!40000 ALTER TABLE `passkeys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
INSERT INTO `password_reset_tokens` VALUES ('ay0820300@gmail.com','$2y$12$3DDHV5L01s877R9OUrfjyul70PYSucmjTsV.mn.R/K8Yn40iTmo1O','2026-07-06 19:48:34');
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `consultation_request_id` bigint unsigned NOT NULL,
  `gateway` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'stripe',
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` bigint unsigned NOT NULL,
  `fee` bigint unsigned DEFAULT NULL,
  `net` bigint unsigned DEFAULT NULL,
  `currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `paid_at` timestamp NULL DEFAULT NULL,
  `payload` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payments_reference_unique` (`reference`),
  KEY `payments_consultation_request_id_index` (`consultation_request_id`),
  KEY `payments_gateway_index` (`gateway`),
  KEY `payments_status_paid_at_index` (`status`,`paid_at`),
  CONSTRAINT `payments_consultation_request_id_foreign` FOREIGN KEY (`consultation_request_id`) REFERENCES `consultation_requests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,3,'stripe','cs_live_a15CBU3EflI2GdBr5HpKMjdJF5814V5IqdQwDTinRyXDE1n699pEmVuc69',500,52,448,'USD','paid','2026-07-04 16:13:08','{\"customer_email\": \"fadwa@test.com\", \"payment_intent\": \"pi_3TpWBeFivz0Hmh0A00b1cqGn\", \"payment_status\": \"paid\", \"transaction_id\": \"pi_3TpWBeFivz0Hmh0A00b1cqGn\"}','2026-07-04 16:13:08','2026-07-05 10:26:50'),(2,7,'stripe','cs_live_a1Wa6g5ErBvpBDM9YnIKYPzyQzuC1AAoQ9DDzVo6ExHKhelC8jQeQWCVnt',9000,426,8574,'USD','paid','2026-07-05 13:49:14','{\"customer_email\": \"ghamedbdear12345678@gmail.com\", \"payment_intent\": \"pi_3TpqPxFivz0Hmh0A10IiZKB0\", \"payment_status\": \"paid\", \"transaction_id\": \"pi_3TpqPxFivz0Hmh0A10IiZKB0\"}','2026-07-05 13:49:14','2026-07-05 13:50:15'),(3,9,'stripe','cs_live_a1CqSYrjgCTckqcVpvakTzgcS3PeFNfAQBTDOIX0jYrBK7lF7vwUDlfLdd',10000,470,9530,'USD','paid','2026-07-05 18:45:19','{\"customer_email\": \"ghamedbdear12345678@gmail.com\", \"payment_intent\": \"pi_3Tpv2UFivz0Hmh0A1P2HmYai\", \"payment_status\": \"paid\", \"transaction_id\": \"pi_3Tpv2UFivz0Hmh0A1P2HmYai\"}','2026-07-05 18:45:19','2026-07-05 18:46:21'),(4,13,'stripe','cs_live_a1psQ9DkeX7LdNUhNdw9vTCieixgnO593lfDkP19vijQP4Ne5qP56n5BBu',10000,470,9530,'USD','paid','2026-07-06 19:17:02','{\"customer_email\": \"ay0820300@gmail.com\", \"payment_intent\": \"pi_3TqI0kFivz0Hmh0A0CFzqAzO\", \"payment_status\": \"paid\", \"transaction_id\": \"pi_3TqI0kFivz0Hmh0A0CFzqAzO\"}','2026-07-06 19:17:02','2026-07-06 19:18:03'),(5,14,'stripe','cs_live_a1jwXRe513u3ZoKxdOG6E74TfL91CB1hrdakZC76LqogNJrhM5jJg8MJzS',10000,470,9530,'USD','paid','2026-07-07 17:46:38','{\"customer_email\": \"haıbegencel@gmail.com\", \"payment_intent\": \"pi_3TqVUFFivz0Hmh0A0qMZnXKk\", \"payment_status\": \"paid\", \"transaction_id\": \"pi_3TqVUFFivz0Hmh0A0qMZnXKk\"}','2026-07-07 17:46:38','2026-07-07 17:47:40');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payouts`
--

DROP TABLE IF EXISTS `payouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payouts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `expert_id` bigint unsigned NOT NULL,
  `amount` bigint unsigned NOT NULL,
  `currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'manual',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idempotency_key` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payouts_idempotency_key_unique` (`idempotency_key`),
  KEY `payouts_expert_id_index` (`expert_id`),
  KEY `payouts_status_index` (`status`),
  CONSTRAINT `payouts_expert_id_foreign` FOREIGN KEY (`expert_id`) REFERENCES `experts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payouts`
--

LOCK TABLES `payouts` WRITE;
/*!40000 ALTER TABLE `payouts` DISABLE KEYS */;
INSERT INTO `payouts` VALUES (1,2,10000,'USD','stripe','failed',NULL,'105eb1d8-2e54-435c-a8c8-d76d01d4fe5e',NULL,NULL,'2026-07-05 13:40:59','2026-07-05 13:40:59'),(2,2,8000,'USD','stripe','failed',NULL,'badeb7fa-e54b-4524-9297-05b7d6f81d9a',NULL,NULL,'2026-07-05 13:51:24','2026-07-05 13:51:25');
/*!40000 ALTER TABLE `payouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plans`
--

DROP TABLE IF EXISTS `plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price` bigint unsigned NOT NULL DEFAULT '0',
  `currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `billing_interval` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'per_engagement',
  `features` json DEFAULT NULL,
  `outcome` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cta_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pay',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plans_slug_unique` (`slug`),
  KEY `plans_is_active_sort_order_index` (`is_active`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plans`
--

LOCK TABLES `plans` WRITE;
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
INSERT INTO `plans` VALUES (1,'International Business Expansion','international-business-expansion','Solutions for companies and entrepreneurs seeking international growth and access to commercial opportunities.',0,'USD','per_engagement','[\"Strategic project analysis\", \"Business positioning study\", \"Commercial opportunity research\", \"B2B introductions & matchmaking\", \"Partner search & identification\", \"Negotiation support\", \"Professional network development\", \"Strategic action plan\"]','Accelerated commercial growth and access to qualified opportunities','Pay now',0,0,1,'2026-07-04 13:41:08','2026-07-08 13:29:45'),(2,'Business Setup & Global Mobility','business-setup-global-mobility','Designed for entrepreneurs, consultants, and investors establishing international business foundations with credibility and operational capacity.',0,'USD','per_engagement','[\"Strategic advisory\", \"Company incorporation support\", \"Administrative support & onboarding\", \"Mobility & residency solutions\", \"Business structuring & branding\", \"Pitch deck & corporate presentation\", \"Business network development\", \"Business development support\"]','A credible professional setup with an international growth strategy','Pay now',0,0,2,'2026-07-04 13:41:08','2026-07-08 13:29:21'),(3,'Business Development as a Service','business-development-as-a-service','Outsourced strategic commercial development for companies seeking deal closure and sustainable growth results.',0,'USD','per_mission','[\"Commercial strategy\", \"B2B pipeline creation\", \"Key account prospecting\", \"Investor & partner search\", \"Commercial offer structuring\", \"Partnership preparation\", \"Executive networking\", \"Commercial representation\", \"Deal negotiation through to closing\"]','Qualified opportunity generation and sustainable commercial growth','Pay now',0,0,3,'2026-07-04 13:41:08','2026-07-08 13:30:09');
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consultation_request_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `expert_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'planning',
  `completion_percentage` tinyint unsigned NOT NULL DEFAULT '0',
  `health` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `health_summary` text COLLATE utf8mb4_unicode_ci,
  `health_flags` json DEFAULT NULL,
  `health_checked_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `projects_uuid_unique` (`uuid`),
  UNIQUE KEY `projects_reference_unique` (`reference`),
  UNIQUE KEY `projects_consultation_request_id_unique` (`consultation_request_id`),
  KEY `projects_user_id_foreign` (`user_id`),
  KEY `projects_expert_id_foreign` (`expert_id`),
  CONSTRAINT `projects_consultation_request_id_foreign` FOREIGN KEY (`consultation_request_id`) REFERENCES `consultation_requests` (`id`) ON DELETE SET NULL,
  CONSTRAINT `projects_expert_id_foreign` FOREIGN KEY (`expert_id`) REFERENCES `experts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `projects_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (1,'4d21b401-e40a-4c57-bb40-9e163ff753b3','PRJ-2026-0001',3,2,NULL,'New Test Plan','active',0,NULL,NULL,NULL,NULL,'2026-07-04 16:13:09','2026-07-04 16:13:09'),(2,'7532c46a-7e78-4b5a-af56-7435147450af','PRJ-2026-0002',7,3,NULL,'Marking Fees','active',0,NULL,NULL,NULL,NULL,'2026-07-05 13:49:14','2026-07-05 13:49:14'),(3,'627ebbdc-2a9c-4610-81f0-f5e2c9e06ba8','PRJ-2026-0003',9,3,NULL,'Speed for FZC — Web Platform Consultation','active',0,NULL,NULL,NULL,NULL,'2026-07-05 18:45:19','2026-07-05 18:45:19'),(4,'5fbe3c53-c2da-4031-9c8a-53b63764b205','PRJ-2026-0004',13,4,NULL,'Consultation','active',0,NULL,NULL,NULL,NULL,'2026-07-06 19:17:03','2026-07-06 19:17:03'),(5,'68282332-32bd-4d44-aebf-116095ba5355','PRJ-2026-0005',21,NULL,NULL,'Consultation','planning',0,NULL,NULL,NULL,NULL,'2026-07-07 16:04:49','2026-07-07 16:04:49'),(6,'ebbfa1b2-7101-44a5-8d38-7c645d173a01','PRJ-2026-0006',14,7,NULL,'Consultation','active',0,NULL,NULL,NULL,NULL,'2026-07-07 17:46:38','2026-07-07 17:46:38'),(7,'7cea3f4a-15f8-47ef-8707-0245873915ac','PRJ-2026-0007',27,NULL,NULL,'Custom plan request','planning',0,NULL,NULL,NULL,NULL,'2026-07-08 16:36:42','2026-07-08 16:36:42'),(8,'9bd6ebeb-dee7-4cf7-9507-427972faa82d','PRJ-2026-0008',28,NULL,NULL,'Custom plan request','planning',0,NULL,NULL,NULL,NULL,'2026-07-09 10:47:16','2026-07-09 10:47:16');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotation_templates`
--

DROP TABLE IF EXISTS `quotation_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotation_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope_items` json DEFAULT NULL,
  `line_items` json DEFAULT NULL,
  `delivery_timeline` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valid_days` smallint unsigned NOT NULL DEFAULT '30',
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quotation_templates_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotation_templates`
--

LOCK TABLES `quotation_templates` WRITE;
/*!40000 ALTER TABLE `quotation_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotation_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','web','2026-07-04 13:41:08','2026-07-04 13:41:08'),(2,'client','web','2026-07-04 13:41:08','2026-07-04 13:41:08');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('3yMD89AKDSarEd7J16hAOeACJZRPbHIkONX5nPQx',NULL,'94.207.202.67','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJmT0VwaUI0Y2ppT0NMMDFjSmtNRXJZRVpLNHVvN1VTbGRTYUxreklLIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL2JsYWNrZGVzY2suYWdlbmN5XC9hZG1pblwvY29uc3VsdGF0aW9ucyJ9LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cHM6XC9cL2JsYWNrZGVzY2suYWdlbmN5XC9hZG1pblwvY29uc3VsdGF0aW9ucyIsInJvdXRlIjoiYWRtaW4uY29uc3VsdGF0aW9ucyJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783244673),('7JfwUk7LRpj3agx8LQgoecAgJzbuK18rlXFx4vEh',NULL,'54.145.77.120','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.47 Safari/537.36','eyJfdG9rZW4iOiJEYk9zSldwRDdrRW1XZDJMY3NvWkdQVE9jSWh4NHV0dXZCSTNjRUl6IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783240657),('82etqwNChPd75HMjzOHF6RKx2dvALADbMmEisj59',NULL,'43.157.82.252','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJOSkhwYnRoYzZmVnlPWkRwdXlKOVVJOEx4OUR0V1F3RFk1ZTBWZUs0IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783243395),('Cr8JdD8TKiMZuQPZOFWWNVJuh0vlSXsjFQe94zBZ',NULL,'94.247.172.129','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2)','eyJfdG9rZW4iOiJ5cExqaDdqZmlXbTRGRUgweVJGT2dRdTdYcFBIMG9lYjFVQ1pRaUJyIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cuYmxhY2tkZXNjay5hZ2VuY3kiLCJyb3V0ZSI6ImhvbWUifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1783243414),('FOunTUalYu8VlcqRJnPGrbg9LoHxrw8UvSx1RUwT',NULL,'104.28.156.61','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJOQTdESUs5QnZ6U0hTTTdORktyUDVXc0RKUnAySHNjQjJqSGViQUNGIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783244681),('goB2fLHoaH1kQVFcMyT8vbd8rRvb1Ps1wJSHo2KN',NULL,'100.56.21.62','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJmVmdDNlVIczhBODhiRjdTZnhEOXhMbklUUDZlN2luY3p0OW5uZ2VTIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783246246),('hmm88ZpBo1Z4DjrmP51B7iRnJHxBVaXRRMfL5q2z',NULL,'52.205.183.147','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36','eyJfdG9rZW4iOiJYZDVRWmpxdmZ3cWswdmo5bE9WZ2w0Vlp2U1JucUNHbnNBc1VLcUNyIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783240643),('kI18VeAeSxzVz2spKNLaFgjP0JfXpveTLLZuv0Rq',NULL,'163.192.193.212','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','eyJfdG9rZW4iOiI1TkZveHhzWGJ4WENNSGZJbXd0WG1PcDltcmVETHR6SFY4WVpXbHBjIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1783244042),('ktCTHd9IdbjQe3EdwszrPJQMZL9gyLstCRCQ7P88',NULL,'45.148.10.200','l9tcpid/v1.1.0','eyJfdG9rZW4iOiJrTld5WmQzMWV5QzNhT3oyb2NzV0NjT3pteldZMXJROXVpMW1Nc2pEIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC8xNTkuODkuODkuMjI0Iiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1783234262),('LvoQbS8VO8dUjZ1s4b9ufKtwQMe5jGp5Lb2xZXOh',NULL,'34.234.223.250','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJKWnB4WGRVNHBGQTI3TWRXS2t2SlMzQWRqV1JQTnFidWdoSVgwR1Q0IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783241083),('M6PBKVndQlOxYluRkazZu6bTpBImWWfwMQXYO7R7',NULL,'45.92.86.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36','eyJfdG9rZW4iOiJhalIxemNRaG5pWHU4R24yN1A1QkxpS2tCeFdGNDViRXphaUtRRTRBIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783244810),('mcF23gdg2nEEhg02lv2JChIvGXZW3sxKZAKMfw30',NULL,'170.106.180.139','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJzY2VvS2hkalc4cEFvQkRZTHNyakhIVHlMb2FaanEwOU9lcXdPMHJOIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783235957),('mHs5tvEosWrsuDgZDbYtbfTWdTkYHMfL1M1Rqx3z',NULL,'95.75.67.202','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJCc25ya3djcWU2a3hPRmxyeEF1YXVDcE13bzV2d2Q4bUtTZ09abWxjIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783238307),('NIbAIm6mYM3jRDj6tGsGRdN1rJf469nv5zEV4QfU',NULL,'111.230.233.46','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJRODUwanJxdXhhRWd1SEZMdThGWHFRSFExZlR3TWZUZVdZdHFEN2tYIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783237120),('Oj2tJUGjq3TWYvJZAKnCXlVTWesQjWnouzByTKUZ',NULL,'100.30.174.180','Mozilla/5.0 (Linux; Android 16; SM-S921U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.7632.6 Mobile Safari/537.36','eyJfdG9rZW4iOiJldHQ3aXhWTG10ZzFEQzBoT2xvcHlSWW95UEJ0d1lxRE11NzZPSnpaIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783245697),('oPklqB7YT8hiSeCPJFs20OCCaWtlGoFbUbMbKjtm',NULL,'192.36.109.96','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123','eyJfdG9rZW4iOiJ5SWRGcGpuUWt3WDM0T1o2SjllbDNKeU4wbzJCOXowd3dhb2M4djhuIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783236805),('pRQGYV2GCxYtK55WFASMHSG0KZQ3XkTIkaiNfB0Z',1,'94.207.202.67','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJ1SU1MN210U0Z1SEkzMzM3Y09mTHJrYTh1RTVPRnljN3JqS0Q3aEdJIiwidXJsIjpbXSwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeVwvbG9naW4iLCJyb3V0ZSI6ImxvZ2luIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjF9',1783246876),('S7Y2SCbB6cLP5iLHpNMtNQ8TnUMgacaDICWA90Ib',NULL,'118.193.37.50','Mozilla/5.0 (compatible; foda-scanner/0.1)','eyJfdG9rZW4iOiJlM0NoekpMZlEwOUpxcm5iemdvNVRuYnhvWGdJVHM3MlF1Vjc0RHJXIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC8xNTkuODkuODkuMjI0Iiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1783246577),('SCh09s63j1gJ2kJ7DkCRNDaHNNxrjmPrfgUwL8Sd',NULL,'43.133.91.48','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJoNVd0OXpaMndLangxSFhRQWpIYXlGRUR2YjdSM2N3R1JlSkNNQ1oyIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC8xNTkuODkuODkuMjI0Iiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1783236741),('TgGxlLZtyaEm7bqRKVp7n40C8b44VBdJI7vLiX9M',NULL,'100.56.21.62','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJoeld6T2JBb2wxWmR1bFE5MG1oME5YRzFLSlo5WGJSRDNma2dEakJXIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783246191),('vr8TieZg5v1PFIAnhWy8gQlAygXbQHLN6hzxnn6F',NULL,'13.222.22.223','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.7632.6 Safari/537.36','eyJfdG9rZW4iOiJjYUcwNHFTZDczeHRPbUI4VmlJQjJmSzRvT25NdDRPN21BdlBSSHhQIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783245698),('vxKj97HF5ofuQB434b9pyoCM70DGMxmdsv6EFECS',NULL,'94.207.202.67','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','eyJfdG9rZW4iOiJ2SDBKcng4eVkxa1RXb3hZSENPQ1AxNnJaZXhRUDlKUlJPbmc0ZjlhIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL2JsYWNrZGVzY2suYWdlbmN5XC9kYXNoYm9hcmQifSwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeVwvZGFzaGJvYXJkIiwicm91dGUiOiJkYXNoYm9hcmQifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1783244631),('WajhR97BeGHK6o1SVV31pbwy5xxg3xqjrgMvWWpM',NULL,'163.192.193.212','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','eyJfdG9rZW4iOiI2aVlKN0o5amxJb0FXWk5JSWxsQXA4YmRPd1hOMWxwQlJ0ZXRQbUZ0IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC8xNTkuODkuODkuMjI0Iiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1783244042),('xbsAModDiKwvdfwuWEOgnm8FFTtB3eP0nN8kGcJZ',NULL,'205.210.31.88','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','eyJfdG9rZW4iOiJhRFNIUGNlQm9KOWVEbzBGNTJ6cXlDUmtUeFIyaVFDZ0RISlNKWm0yIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC8xNTkuODkuODkuMjI0Iiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1783240177),('Zb7TCjJz1X30vlCwmzQmDJzWSG71tQVRbyRQzxTS',NULL,'157.173.126.60','Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.1.15','eyJfdG9rZW4iOiJ3MFg3eE5GRjVLdEVVZGhTblJIaGRzbWg5aWR6YlhPM0p0bTlrU2ZuIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783238692),('zZfiurug0ZVPtZbcu9BYaG1UHreQ4vlYYsFNL1v7',NULL,'3.90.72.181','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:77.0) Gecko/20100101 Firefox/77.0','eyJfdG9rZW4iOiJNY29pSjdCTXplczhpY1RuMVptVklseURNOWZwMmxwQ2lOc2p6QjBDIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9ibGFja2Rlc2NrLmFnZW5jeSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1783241161);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `payload` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_group_name_unique` (`group`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'platform','currency_code',0,'\"USD\"','2026-07-04 13:41:07','2026-07-04 13:41:07'),(2,'platform','currency_symbol',0,'\"$\"','2026-07-04 13:41:07','2026-07-04 13:41:07'),(3,'platform','tax_rate',0,'0','2026-07-04 13:41:07','2026-07-04 13:41:07'),(4,'platform','company_name',0,'\"BlackDesck Agency LLC\"','2026-07-04 13:41:07','2026-07-07 15:47:34'),(5,'platform','company_email',0,'null','2026-07-04 13:41:07','2026-07-04 13:41:07'),(6,'platform','company_address',0,'\"Wyoming, United States\"','2026-07-04 13:41:07','2026-07-07 15:47:34'),(7,'platform','vat_number',0,'null','2026-07-04 13:41:07','2026-07-04 13:41:07'),(8,'platform','invoice_footer',0,'null','2026-07-04 13:41:07','2026-07-04 13:41:07'),(9,'platform','signatory_name',0,'\"Fadoua Fakir\"','2026-07-07 15:47:34','2026-07-07 15:47:34'),(10,'platform','signatory_title',0,'\"Managing Director\"','2026-07-07 15:47:34','2026-07-07 15:47:34');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Fadwa','fadwa.9x7k2q@blackdesck.io','2026-07-04 13:41:08','$2y$12$Jthg8YWAORaF71S6lFegxuSYt3Pribb50LMXNjax65ChUmbR2YgPK',NULL,NULL,NULL,'ZBxy9LAVvTTt6weOPsu88Re9SA8yWHrduK3yfNVn9B3M4p8d3cnqXUWHa1EF','2026-07-04 13:41:08','2026-07-04 13:41:08'),(2,'Fadwa Fakir Test','fadwa@test.com','2026-07-04 16:13:09','$2y$12$zvbubK0Nz8itC8B3aoOGYuQ7Ii1Z9ZxxFcglTldWfxKItvame4xPW',NULL,NULL,NULL,NULL,'2026-07-04 16:13:09','2026-07-04 16:13:09'),(3,'Speed of FZC','ghamedbdear12345678@gmail.com','2026-07-05 13:49:14','$2y$12$ocYI1hK6ucELylGJSp5a4.IvvxLpupw8/Pb91FEqeaJbX3ZvOeezu',NULL,NULL,NULL,NULL,'2026-07-05 13:49:14','2026-07-05 13:49:14'),(4,'MARRAKECH CO','ay0820300@gmail.com','2026-07-06 19:17:02','$2y$12$W4n50/ckmOBMFH/oKaTveelht16hc.7szSF3WAGxC8z5f0wLlswUC',NULL,NULL,NULL,NULL,'2026-07-06 19:17:02','2026-07-06 19:17:02'),(5,'lisa vogel','lisavogel017@gmail.com',NULL,'$2y$12$EtQhbtFA7WxHtb1mbjjdbeyOpIVvfi24Tumd1NhGlyrwVWx25vdoC',NULL,NULL,NULL,NULL,'2026-07-06 22:10:13','2026-07-06 22:10:13'),(6,'Emre hakyemez','soyluahmet123456789@gmail.com',NULL,'$2y$12$C9fjBQjad61FVt.5gSB31er9fHsCx4AsFHdmSw6/Xr18OQehcEy2K',NULL,NULL,NULL,NULL,'2026-07-06 22:15:02','2026-07-06 22:15:02'),(7,'Ziya erdal','haıbegencel@gmail.com','2026-07-07 17:46:38','$2y$12$9/p0B3AbzTF6RlJjKVxGluaBfky.OENM9QHhnhMXbdHBa0W1PkX/K',NULL,NULL,NULL,NULL,'2026-07-07 17:46:38','2026-07-07 17:46:38'),(8,'md saimon','mehedy303@gmail.com',NULL,'$2y$12$W4YEYjvVwG9PY1C35irZ3.EWvn4QTZSsk6tIGT1EbyeNET.l2lk36',NULL,NULL,NULL,NULL,'2026-07-08 16:37:41','2026-07-08 16:37:41');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'blackdesck'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-09 19:06:04
